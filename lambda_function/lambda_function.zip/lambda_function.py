import json
import boto3
import os
import pymysql

# Initialize S3 client
s3_client = boto3.client('s3')

# Load environment variables
BUCKET_NAME = os.environ['BUCKET_NAME']
DB_CONFIG = {
    "host": os.environ['DB_HOST'],
    "user": os.environ['DB_USERNAME'],
    "password": os.environ['DB_PASSWORD'],
    "database": os.environ['DB_NAME']
}

def lambda_handler(event, context):
    try:
        # Parse event for file content and filename
        file_content = event['body']
        file_name = event['headers']['filename']
        
        # Upload file to S3
        s3_client.put_object(Bucket=BUCKET_NAME, Key=file_name, Body=file_content)
        print(f"Uploaded {file_name} to S3 bucket {BUCKET_NAME}")
        
        # Save filename to MySQL database
        connection = pymysql.connect(
            host=DB_CONFIG['host'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database']
        )
        with connection.cursor() as cursor:
            sql = "INSERT INTO files (filename) VALUES (%s)"
            cursor.execute(sql, (file_name,))
            connection.commit()
            print(f"Saved {file_name} to database")
    except Exception as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
    finally:
        if 'connection' in locals() and connection.open:
            connection.close()

    return {
        'statusCode': 200,
        'body': json.dumps({'message': f'File {file_name} uploaded successfully'})
    }
